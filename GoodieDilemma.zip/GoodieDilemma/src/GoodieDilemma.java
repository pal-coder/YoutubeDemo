/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.io.FileWriter;

/**
 *
 * @author pallavi
 */
public class GoodieDilemma {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int lineIndex = 1;
        int employeeCount = 0;
        HashMap<String, Integer> goodiesDict = new HashMap<String, Integer>();
        try {
            File inputFile = new File("./src/sample_input.txt");
            Scanner myFileScanner = new Scanner(inputFile);

            while (myFileScanner.hasNextLine()) {
                String line = myFileScanner.nextLine();
                if (lineIndex == 1) {
                    employeeCount = Integer.parseInt(line.split(":")[1].trim());
                } else if (lineIndex >= 5) {
                    goodiesDict.put(line.split(":")[0].trim(), Integer.parseInt(line.split(":")[1].trim()));
                }
                lineIndex++;
            }
            myFileScanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("Error: Unable to open the file or file not found.");
            e.printStackTrace();
        }

        System.out.println("INPUT:\n");
        System.out.println("No.of Employees = " + employeeCount);

        System.out.println("Goodies List");
        for (String keyName : goodiesDict.keySet()) {
            System.out.println(keyName + " = " + goodiesDict.get(keyName));
        }

        int goodiesCount = goodiesDict.size();
        if (employeeCount > goodiesCount) {
            System.out.println("Employees are more than available goodies. You cannot distribute.");
            System.exit(1);
        }

        // Sort Goodies by their value
        Map<String, Integer> sortedGoodiesDict = sortByValues(goodiesDict);
        System.out.println("\n\nAfter Sorting Goodies by their value:");
        for (String keyName : sortedGoodiesDict.keySet()) {
            System.out.println(keyName + " = " + sortedGoodiesDict.get(keyName));
        }

        // Fetch the list of goodies to employees
        int firstIndex = 0;
        int lastIndex = 0;
        int diffAmount = Integer.MAX_VALUE;
        List<Integer> gValues = new ArrayList<Integer>(sortedGoodiesDict.values());
        for (int i = 0; i < employeeCount - 1; i++) {
            int minValue = gValues.get(i);
            int maxValue = gValues.get(i + employeeCount - 1);
            int diff = maxValue - minValue;
            if (diff < diffAmount) {
                diffAmount = diff;
                firstIndex = i;
                lastIndex = i + employeeCount - 1;
            }
        }

        // Output
        System.out.println("OUTPUT:\n");
        // The goodies to be distributed are
        System.out.println("\n\nThe goodies to distribute are:\n");
        int i = 0;
        String outputString = new String();
        outputString = "No.of Employees: " + employeeCount + "\n\n";
        for (Map.Entry<String, Integer> entry : sortedGoodiesDict.entrySet()) {
            if (i >= firstIndex && i <= lastIndex) {
                String str = entry.getKey() + " = " + entry.getValue();
                outputString = outputString + str + "\n";
                System.out.println(str);
            }
            i++;
        }
        outputString = outputString + "And the difference between the chosen goodie with highest price and the lowest price is " + diffAmount;
        System.out.println("And the difference between the chosen goodie with highest price and the lowest price is " + diffAmount);

        try {
            FileWriter fw = new FileWriter("./src/output.txt");
            fw.write(outputString);
            fw.close();
        } catch (Exception ex) {
        }
    }

    private static HashMap sortByValues(HashMap map) {
        List list = new LinkedList(map.entrySet());
        // Defined Custom Comparator here
        Collections.sort(list, new Comparator() {
            public int compare(Object o1, Object o2) {
                return ((Comparable) ((Map.Entry) (o1)).getValue())
                        .compareTo(((Map.Entry) (o2)).getValue());
            }
        });

        HashMap sortedHashMap = new LinkedHashMap();
        for (Iterator it = list.iterator(); it.hasNext();) {
            Map.Entry entry = (Map.Entry) it.next();
            sortedHashMap.put(entry.getKey(), entry.getValue());
        }
        return sortedHashMap;
    }
}
